import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'providers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final container = ProviderContainer();
  await container.read(appRepositoryProvider).init();
  runApp(UncontrolledProviderScope(
    container: container,
    child: const PowerlineApp(),
  ));
}
