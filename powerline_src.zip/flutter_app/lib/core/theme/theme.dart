/// Powerline visual system: dark graphite base, pale-gray type, deep crimson
/// accent, explicit call-state colors. No purple SaaS gradients.
library;

import 'package:flutter/material.dart';

class PowerlineColors {
  static const graphite = Color(0xFF15171A);
  static const graphitePanel = Color(0xFF1D2024);
  static const graphiteRaised = Color(0xFF24282E);
  static const border = Color(0xFF32373E);
  static const textPrimary = Color(0xFFF2F3F5);
  static const textSecondary = Color(0xFFA6ADB6);
  static const crimson = Color(0xFF9E1B32);
  static const crimsonBright = Color(0xFFC42847);
  // Call-state colors
  static const stateRinging = Color(0xFFE8B93B);
  static const stateConnected = Color(0xFF3BB273);
  static const stateHold = Color(0xFF4F9DDE);
  static const stateFailed = Color(0xFFD64545);
  static const stateVoicemail = Color(0xFF8E6FD8);
}

ThemeData powerlineTheme() {
  const scheme = ColorScheme.dark(
    surface: PowerlineColors.graphite,
    primary: PowerlineColors.crimsonBright,
    secondary: PowerlineColors.crimson,
    onSurface: PowerlineColors.textPrimary,
    error: PowerlineColors.stateFailed,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: PowerlineColors.graphite,
    cardTheme: const CardThemeData(
      color: PowerlineColors.graphitePanel,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        side: BorderSide(color: PowerlineColors.border),
      ),
      margin: EdgeInsets.zero,
    ),
    dividerTheme: const DividerThemeData(color: PowerlineColors.border, space: 1),
    appBarTheme: const AppBarTheme(
      backgroundColor: PowerlineColors.graphite,
      foregroundColor: PowerlineColors.textPrimary,
      elevation: 0,
    ),
    listTileTheme: const ListTileThemeData(
      iconColor: PowerlineColors.textSecondary,
      textColor: PowerlineColors.textPrimary,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: PowerlineColors.graphiteRaised,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: PowerlineColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: PowerlineColors.crimsonBright, width: 2),
      ),
    ),
    focusColor: PowerlineColors.crimsonBright.withValues(alpha: 0.25),
    tooltipTheme: const TooltipThemeData(waitDuration: Duration(milliseconds: 400)),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: PowerlineColors.graphiteRaised,
      contentTextStyle: TextStyle(color: PowerlineColors.textPrimary),
    ),
  );
}

/// Original Powerline wordmark rendered purely with typography.
class PowerlineWordmark extends StatelessWidget {
  final double size;
  const PowerlineWordmark({super.key, this.size = 20});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size * 0.55,
          height: size * 1.1,
          decoration: BoxDecoration(
            color: PowerlineColors.crimsonBright,
            borderRadius: BorderRadius.circular(2),
          ),
          child: CustomPaint(painter: _BoltPainter()),
        ),
        SizedBox(width: size * 0.4),
        Text.rich(
          TextSpan(children: [
            TextSpan(
              text: 'POWER',
              style: TextStyle(
                fontSize: size,
                fontWeight: FontWeight.w800,
                letterSpacing: size * 0.12,
                color: PowerlineColors.textPrimary,
              ),
            ),
            TextSpan(
              text: 'LINE',
              style: TextStyle(
                fontSize: size,
                fontWeight: FontWeight.w300,
                letterSpacing: size * 0.12,
                color: PowerlineColors.textSecondary,
              ),
            ),
          ]),
        ),
      ],
    );
  }
}

class _BoltPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = Colors.white.withValues(alpha: 0.9);
    final path = Path()
      ..moveTo(size.width * 0.62, size.height * 0.08)
      ..lineTo(size.width * 0.22, size.height * 0.55)
      ..lineTo(size.width * 0.48, size.height * 0.55)
      ..lineTo(size.width * 0.38, size.height * 0.92)
      ..lineTo(size.width * 0.78, size.height * 0.45)
      ..lineTo(size.width * 0.52, size.height * 0.45)
      ..close();
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Standard "demo mode" banner chip used wherever simulated activity shows.
class DemoBadge extends StatelessWidget {
  final String label;
  const DemoBadge({super.key, this.label = 'DEMO'});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: PowerlineColors.stateRinging.withValues(alpha: 0.15),
        border: Border.all(color: PowerlineColors.stateRinging),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(label,
          style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: PowerlineColors.stateRinging,
              letterSpacing: 1)),
    );
  }
}
