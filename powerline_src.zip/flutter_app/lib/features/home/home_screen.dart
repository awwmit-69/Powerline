/// Home dashboard: provider status, unread/missed counts, quick actions.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/theme.dart';
import '../../core/util/phone.dart';
import '../../domain/models/enums.dart';
import '../../providers.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = stateOf(ref);
    final unreadMsgs = s.conversations.fold<int>(0, (a, c) => a + c.unreadCount);
    final today = DateTime.now();
    final callsToday = s.calls
        .where((c) =>
            c.startedAt.year == today.year &&
            c.startedAt.month == today.month &&
            c.startedAt.day == today.day)
        .length;
    final missed = s.calls.where((c) => c.missed).length;
    final newVms = s.voicemails.where((v) => !v.read).length;
    final upcomingCallbacks = s.callbacks.where((c) => !c.done).length;
    final upcomingAppts = s.appointments
        .where((a) => a.startsAt.isAfter(today) && a.status == AppointmentStatus.scheduled)
        .length;
    final activeCampaigns =
        s.campaigns.where((c) => c.status == CampaignStatus.active).length;
    final mainNumber = s.numbers.isEmpty ? null : s.numbers.first;
    final warnings = s.notifications.where((n) => !n.read).take(4).toList();
    final integErrors =
        s.integrations.where((i) => i.state == ProviderState.error).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 24,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Your Powerline number',
                        style: TextStyle(color: PowerlineColors.textSecondary, fontSize: 12)),
                    Text(
                      mainNumber == null
                          ? 'No number yet'
                          : '${PhoneNumberUtil.format(mainNumber.e164)} · ${mainNumber.label}',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
                const DemoBadge(label: 'DEMO NUMBER — not provisioned'),
                const Chip(
                  avatar: Icon(Icons.cloud_off, size: 14),
                  label: Text('Provider: Demo (local simulation)'),
                ),
                FilledButton.icon(
                  onPressed: () => context.go('/dialpad'),
                  icon: const Icon(Icons.dialpad, size: 16),
                  label: const Text('Dialpad'),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.go('/messages'),
                  icon: const Icon(Icons.add_comment_outlined, size: 16),
                  label: const Text('New message'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _Stat('Unread messages', '$unreadMsgs', Icons.chat_bubble_outline, '/messages'),
            _Stat('Missed calls', '$missed', Icons.phone_missed, '/calls'),
            _Stat('New voicemails', '$newVms', Icons.voicemail, '/voicemail'),
            _Stat('Calls today', '$callsToday', Icons.call, '/calls'),
            _Stat('Callbacks due', '$upcomingCallbacks', Icons.update, '/campaigns'),
            _Stat('Appointments', '$upcomingAppts', Icons.event_available, '/campaigns'),
            _Stat('Active campaigns', '$activeCampaigns', Icons.campaign_outlined, '/campaigns'),
            _Stat('AI agents (test mode)', '${s.agents.length}', Icons.smart_toy_outlined, '/agents'),
          ],
        ),
        const SizedBox(height: 16),
        if (warnings.isNotEmpty || integErrors.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Warnings & notifications',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  for (final w in warnings)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.warning_amber, color: PowerlineColors.stateRinging),
                      title: Text(w.title),
                      subtitle: Text(w.body),
                      trailing: TextButton(
                        onPressed: () =>
                            ref.read(appRepositoryProvider).markNotificationRead(w.id),
                        child: const Text('Dismiss'),
                      ),
                    ),
                  for (final e in integErrors)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.error_outline, color: PowerlineColors.stateFailed),
                      title: Text('${e.provider} integration error'),
                      subtitle: Text(e.lastError ?? 'unknown'),
                      onTap: () => context.go('/settings'),
                    ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Recent conversations', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                for (final conv in ([...s.conversations]
                      ..sort((a, b) => (b.lastMessageAt ?? DateTime(0))
                          .compareTo(a.lastMessageAt ?? DateTime(0))))
                    .take(6))
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.chat_outlined),
                    title: Text(_contactName(ref, conv.contactId) ??
                        PhoneNumberUtil.format(conv.remoteE164)),
                    subtitle: Text(
                      _lastBody(ref, conv.id),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: conv.unreadCount > 0
                        ? CircleAvatar(
                            radius: 10,
                            backgroundColor: PowerlineColors.crimsonBright,
                            child: Text('${conv.unreadCount}',
                                style: const TextStyle(fontSize: 10)))
                        : null,
                    onTap: () => context.go('/messages'),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  String? _contactName(WidgetRef ref, String? contactId) {
    if (contactId == null) return null;
    final s = stateOf(ref);
    final matches = s.contacts.where((c) => c.id == contactId);
    return matches.isEmpty ? null : matches.first.displayName;
  }

  String _lastBody(WidgetRef ref, String convId) {
    final s = stateOf(ref);
    final msgs = s.messages.where((m) => m.conversationId == convId).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return msgs.isEmpty ? '' : msgs.first.body;
  }
}

class _Stat extends ConsumerWidget {
  final String label;
  final String value;
  final IconData icon;
  final String route;
  const _Stat(this.label, this.value, this.icon, this.route);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      width: 180,
      child: Card(
        child: InkWell(
          onTap: () => context.go(route),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(icon, size: 20, color: PowerlineColors.crimsonBright),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(value,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                      Text(label,
                          style: const TextStyle(
                              fontSize: 11, color: PowerlineColors.textSecondary)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
